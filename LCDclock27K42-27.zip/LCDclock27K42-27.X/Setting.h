/* 
 * File:   Setting.h
 * Author: ohno
 *
 * Created on 2022/01/15, 22:09
 */

#ifndef SETTING_H
#define	SETTING_H

#ifdef	__cplusplus
extern "C" {
#endif


#include "mcc_generated_files/mcc.h"

// TODO Insert declarations or function prototypes (right here) to leverage 
// live documentation

void SettingEventHandler(void);


#ifdef	__cplusplus
}
#endif /* __cplusplus */

#endif	/* SETTING_H */
