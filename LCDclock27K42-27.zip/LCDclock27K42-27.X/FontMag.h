/* 
 * File:   FontMag.h
 * Author: ohno
 *
 * Created on June 2, 2022, 8:38 PM
 */

#ifndef FONTMAG_H
#define	FONTMAG_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "mcc_generated_files/mcc.h"

    
void FontMagEventHandler(void);


#ifdef	__cplusplus
}
#endif

#endif	/* FONTMAG_H */

