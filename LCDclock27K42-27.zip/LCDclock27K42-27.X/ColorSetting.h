/* 
 * File:   ColorSetting.h
 * Author: K.Ohno
 *
 * Created on May 15, 2022, 10:50 AM
 */

#ifndef COLORSETTING_H
#define	COLORSETTING_H

#ifdef	__cplusplus
extern "C" {
#endif


#include "mcc_generated_files/mcc.h"

void ColorSettingEventHandler(void);


#ifdef	__cplusplus
}
#endif

#endif	/* NEWFILE_H */
