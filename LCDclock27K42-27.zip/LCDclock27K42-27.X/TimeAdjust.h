/* 
 * File:   ManualAdj.h
 * Author: ohno
 *
 * Created on 2022/01/16, 18:36
 */

#ifndef MANUALADJ_H
#define	MANUALADJ_H

#ifdef	__cplusplus
extern "C" {
#endif


#include "mcc_generated_files/mcc.h"

void TimeAdjustEventHandler();



#ifdef	__cplusplus
}
#endif

#endif	/* MANUALADJ_H */
