/* 
 * File:   CustomData.h
 * Author: ohno
 *
 * Created on March 6, 2022, 5:12 PM
 */

#ifndef CUSTOMDATA_H
#define	CUSTOMDATA_H

#ifdef	__cplusplus
extern "C" {
#endif

    
#include "mcc_generated_files/mcc.h"

void CustomDataEventHandler(void);


#ifdef	__cplusplus
}
#endif

#endif	/* CUSTOMDATA_H */
